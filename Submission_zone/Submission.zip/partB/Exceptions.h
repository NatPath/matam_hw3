#ifndef _GAME_EXCEPTIONS_H_
#define _GAME_EXCEPTIONS_H_

namespace mtm{
    class Exception : public std::exception{};
}


#endif